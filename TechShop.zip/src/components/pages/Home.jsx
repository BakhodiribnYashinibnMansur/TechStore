import React from 'react';
import AddsCarousel from '../layout/AddsCaruosel';
import Navbar from '../layout/Navbar';
import '../../style/page/Home.scss';
const Home = () => {
	return (
		<div className="container">
			<Navbar />
			<AddsCarousel />
		</div>
	);
};
export default Home;
