import React, { useState, useEffect } from 'react';
import ImgCarousel from './ImgCarousel';
import img1 from '../../Img/carousel/img1.jpg';
import img2 from '../../Img/carousel/img2.jpg';
import img3 from '../../Img/carousel/img3.jpg';
import img4 from '../../Img/carousel/img4.jpg';
import img5 from '../../Img/carousel/img5.jpg';
import img6 from '../../Img/carousel/img6.jpg';
import img7 from '../../Img/carousel/img7.jpg';

import '../../style/layout/AddsCarousel.scss';
import logo from '../../Img/logo/logo.png';

const AddsCarousel = () => {
	const sliderArr = [
		<ImgCarousel className="carouselImg" src={img1} />,
		<ImgCarousel className="carouselImg" src={img2} />,
		<ImgCarousel className="carouselImg" src={img3} />,
		<ImgCarousel className="carouselImg" src={img4} />,
		<ImgCarousel className="carouselImg" src={img5} />,
		<ImgCarousel className="carouselImg" src={img6} />,
		<ImgCarousel className="carouselImg" src={img7} />
	];

	const [ step, setStep ] = useState(0);
	useEffect(() => {}, []);

	const carouselInterval = setInterval(() => {
		if (step <= 0) {
			setStep((prevState) => prevState - 100);
		}
	}, 10000);

	if (step <= -700) {
		setStep(0);
	}
	const carouselRenderImg = () => {
		return sliderArr.map((item, index) => {
			return (
				<div
					className="slide-div"
					key={index}
					style={{ transform: `translateX(${step}%)`, transition: 'all 1s' }}>
					{item}
				</div>
			);
		});
	};

	return (
		<div className="carousel-div">
			<div className="carousel-outer">
				<div className="triangle-div">
					<span
						className={

								step === 0 ? 'triangle-link-active' :
								'triangle-link'
						}
						onClick={() => {
							setStep(0);

							if (carouselInterval) {
								setInterval(carouselInterval);
							} else {
								clearInterval(carouselInterval);
							}
						}}
					/>
					<span
						className={

								step === -100 ? 'triangle-link-active' :
								'triangle-link'
						}
						onClick={() => {
							setStep(-100);
							clearInterval(carouselInterval);
							if (carouselInterval) {
								setInterval(carouselInterval);
							} else {
								clearInterval(carouselInterval);
							}
						}}
					/>
					<span
						className={

								step === -200 ? 'triangle-link-active' :
								'triangle-link'
						}
						onClick={() => {
							setStep(-200);
							clearInterval(carouselInterval);
							if (carouselInterval) {
								setInterval(carouselInterval);
							} else {
								clearInterval(carouselInterval);
							}
						}}
					/>
					<span
						className={

								step === -300 ? 'triangle-link-active' :
								'triangle-link'
						}
						onClick={() => {
							setStep(-300);
							clearInterval(carouselInterval);
							if (carouselInterval) {
								setInterval(carouselInterval);
							} else {
								clearInterval(carouselInterval);
							}
						}}
					/>
					<span
						className={

								step === -400 ? 'triangle-link-active' :
								'triangle-link'
						}
						onClick={() => {
							setStep(-400);
							clearInterval(carouselInterval);
							if (carouselInterval) {
								setInterval(carouselInterval);
							} else {
								clearInterval(carouselInterval);
							}
						}}
					/>
					<span
						className={

								step === -500 ? 'triangle-link-active' :
								'triangle-link'
						}
						onClick={() => {
							setStep(-500);
							clearInterval(carouselInterval);
							if (carouselInterval) {
								setInterval(carouselInterval);
							} else {
								clearInterval(carouselInterval);
							}
						}}
					/>
					<span
						className={

								step === -600 ? 'triangle-link-active' :
								'triangle-link'
						}
						onClick={() => {
							setStep(-600);
							clearInterval(carouselInterval);
							if (carouselInterval) {
								setInterval(carouselInterval);
							} else {
								clearInterval(carouselInterval);
							}
						}}
					/>
				</div>
				<div className="carousel-inner">{carouselRenderImg()}</div>
				<div className="logo-div">
					<img src={logo} alt="" className="logo-img" />
				</div>
				<div className="line-div">
					<div
						className="line"
						style={{ width: ` ${4 * Math.abs(step / 100) + 4}rem`, transition: 'all .7s' }}
					/>
				</div>
			</div>
		</div>
	);
};
export default AddsCarousel;
